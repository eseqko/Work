# GrizzNet — Student Resource Hub

A static, embeddable student self-advocacy compendium for high school students. Covers graduation requirements, A-G / college prep, financial aid, student rights, self-advocacy, school handbook, and support resources — in English, Spanish, Arabic (RTL), and Filipino.

Designed to be embedded in a Google Site via iframe. Hosted on Netlify (free tier, works with private repos, automatic HTTPS).

---

## Deploy to Netlify

### Step 1 — Create a Netlify account
Go to [netlify.com](https://netlify.com) and sign up with your GitHub account. This links them automatically.

### Step 2 — Import this repo
1. From your Netlify dashboard, click **Add new site**
2. Select **Import an existing project**
3. Choose **GitHub** as your Git provider
4. Find and select this repo (`GrizzNet`) — it will appear even though it's private
5. Leave all build settings blank — there is no build step needed:
   - **Base directory:** *(leave empty)*
   - **Build command:** *(leave empty)*
   - **Publish directory:** `.`
6. Click **Deploy site**

Netlify will deploy in about 30 seconds. You'll get a URL like:
`https://random-name-123.netlify.app`

You can rename it under **Site settings → Site details → Change site name**.

### Step 3 — You're done
The `_headers` and `netlify.toml` files in this repo are already configured to allow Google Sites to embed the page. No extra settings needed.

Every time you push a change to this branch, Netlify redeploys automatically.

---

## Embed in Google Sites

1. Open your Google Site and edit the page where you want the hub
2. Click **Insert → Embed**
3. Paste your Netlify URL (e.g. `https://your-site-name.netlify.app`)
4. Click **Next → Insert**
5. Resize the embed block — **700–800px height** works well on desktop; students on phones will scroll within the embed

---

## Fill In Your School's Content

Open `index.html` and search for `📌 Placeholder` — each one tells you exactly what to add. Key sections:

| Section | What to add |
|---------|------------|
| `graduation` → "What do I need to graduate?" | Your school's actual credit totals per subject area |
| `graduation` → "What other requirements are there?" | Senior project, community service hours, state assessment, etc. |
| `aid` → "Local and school scholarships" | Local scholarships with deadlines and application links |
| `advocacy` → "Advocating in another language" | Bilingual staff or parent/student liaison contact info |
| `handbook` → "About this section" | Key policies from your student handbook |
| `support` → "School-based support" | Counselor names and hours, school psychologist, wellness center |
| `support` → "Community resources" | Local mental health clinics, county resources, youth programs |

After editing, save the file, commit, and push — Netlify will redeploy automatically within ~30 seconds.

---

## Adding Translations

The `es` (Spanish), `ar` (Arabic), and `fil` (Filipino) entries in the `LANG` object inside `index.html` already have translated navigation labels. To add translated content for a section:

1. Find `const LANG=` in `index.html`
2. Copy a section from `LANG.en.sections` (e.g. `graduation: { title, desc, items: [...] }`)
3. Paste it into the same language's `sections: {}` object
4. Translate the `title`, `desc`, and each `q` (question) and `a` (answer) field
5. Save, commit, push — done

Until a section is translated, the page displays the English content with a "translation coming soon" notice in the selected language.

---

## Privacy

- No student data is collected or stored — purely static content
- No analytics, no cookies, no tracking
- Nothing leaves the student's browser
- No PII involved — safe for school use
- Netlify does not require a data processing agreement for static informational sites with no user data collection
